<?php
if(PHP_SAPI!=='cli' && realpath($_SERVER['SCRIPT_FILENAME']??'')===__FILE__){http_response_code(404);exit;}
return ['version'=>1,'mode'=>'protected','directory'=>'nsc-private-56ce1b547f7cdb626c17407b','setup_token_hash'=>'9b92b37c7d634f66a3a67f16d78cfe4232706e18b7f53a48763975a1fc138d4e'];
